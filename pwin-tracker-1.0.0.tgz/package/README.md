# PWIN Tracker Electron App

This Electron app converts the PWIN worksheet logic into a desktop workflow.

## Features

- Home screen with **Add New Opportunity** and **Update Opportunity PWIN**
- Opportunity record with name and optional solicitation number
- Yes, Unsure, and No radio buttons for every PWIN question
- Category composite scores and total PWIN score
- Historical update tracking with one row per assessment update
- Home button to return to the main screen
- Export selected opportunity history to Excel
- Local JSON storage in the Electron user data folder

## Scoring logic carried from the spreadsheet

- Yes = 100
- Unsure = 25
- No = 0
- Category score = average of question scores within that category
- Total PWIN = average of the seven category scores

## Run locally

1. Open a terminal in this folder
2. Install dependencies

   npm install

3. Start the app

   npm start

## Notes

The app stores opportunity data in the Electron app data folder, not inside the project directory.


Security note

This version uses the `exceljs` package for spreadsheet export instead of `xlsx` because the npm `xlsx` package reports unresolved high severity advisories in `npm audit`.
